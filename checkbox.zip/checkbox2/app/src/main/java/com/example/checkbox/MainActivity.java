package com.example.checkbox;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private CheckBox ingles, espanhol;
    private RadioButton vista;
    private Button calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ingles = findViewById(R.id.ingles);
        espanhol = findViewById(R.id.espanhol);
        vista = findViewById(R.id.vista);
        calcular = findViewById(R.id.calcular);

        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double total = 0;

                // Calcula o valor do curso baseado nas seleções
                if (ingles.isChecked() && espanhol.isChecked()) {
                    total = 2400; // Inglês e Espanhol
                } else if (ingles.isChecked()) {
                    total = 1614; // Apenas Inglês
                } else if (espanhol.isChecked()) {
                    total = 1200; // Apenas Espanhol
                }

                // Aplica desconto se o pagamento for à vista
                if (vista.isChecked()) {
                    total *= 0.9; // 10% de desconto
                }

                // Exibe o total
                Toast.makeText(MainActivity.this, "Total: R$ " + total, Toast.LENGTH_SHORT).show();
            }
        });
    }
}